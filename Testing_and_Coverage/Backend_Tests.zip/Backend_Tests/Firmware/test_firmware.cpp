#include <gtest/gtest.h>
#include <gmock/gmock.h>

#define private public
#define protected public
#include "Firmware/firmware_manager.h"
#include "Firmware/firmware_uploader.h"
#undef private
#undef protected

#include <nlohmann/json.hpp>
#include <vector>
#include <string>
#include <thread>
#include <chrono>
#include <fstream>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <atomic>
#include <iostream>

using namespace testing;
using json = nlohmann::json;

// Mock bootloader over PTY
class MockBootloader {
public:
    int master_fd = -1;
    std::string slave_name;
    std::thread bl_thread;
    std::atomic<bool> running{false};

    uint32_t board_id = 9;
    uint32_t flash_size = 100;
    uint32_t expected_crc = 0x0;

    bool fail_erase = false;
    bool timeout_erase = false;
    bool nack_prog = false;
    bool timeout_prog = false;
    bool timeout_get_device = false;
    bool fail_crc = false;
    bool invalid_device_info = false;
    bool unexpected_status_device = false;
    int sync_retries_needed = 0;

    void start() {
        master_fd = posix_openpt(O_RDWR | O_NOCTTY);
        grantpt(master_fd);
        unlockpt(master_fd);
        slave_name = ptsname(master_fd);

        running = true;
        bl_thread = std::thread([this]() {
            uint8_t buf[2048];
            while (running) {
                fd_set set;
                FD_ZERO(&set);
                FD_SET(master_fd, &set);
                struct timeval tv = {0, 50000}; // 50ms
                int rv = select(master_fd + 1, &set, NULL, NULL, &tv);
                if (rv > 0) {
                    int n = read(master_fd, buf, sizeof(buf));
                    if (n > 0) {
                        process_data(buf, n);
                    }
                }
            }
        });
    }

    void stop() {
        running = false;
        if (bl_thread.joinable()) bl_thread.join();
        if (master_fd >= 0) {
            close(master_fd);
            master_fd = -1;
        }
    }

    void process_data(uint8_t* data, int len) {
        for (int i = 0; i < len; i++) {
            uint8_t b = data[i];
            if (b == 0x7F) { // autopilot sync byte
                // ignore
            } else if (b == 0x21) { // GET_SYNC
                if (i + 1 < len && data[i+1] == 0x20) {
                    if (sync_retries_needed > 0) {
                        sync_retries_needed--;
                        // timeout
                    } else {
                        send_insync_ok();
                    }
                    i++;
                }
            } else if (b == 0x22) { // GET_DEVICE
                if (timeout_get_device) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(300));
                }
                if (i + 2 < len && data[i+2] == 0x20) {
                    uint8_t param = data[i+1];
                    uint32_t val = 0;
                    if (param == 0x02) val = board_id;
                    else if (param == 0x04) val = flash_size;
                    
                    uint8_t resp[6] = {
                        (uint8_t)(val & 0xFF),
                        (uint8_t)((val >> 8) & 0xFF),
                        (uint8_t)((val >> 16) & 0xFF),
                        (uint8_t)((val >> 24) & 0xFF),
                        0x12, // INSYNC
                        0x10  // OK
                    };
                    if (invalid_device_info) resp[5] = 0x13;
                    else if (unexpected_status_device) resp[5] = 0x11;
                    
                    write(master_fd, resp, 6);
                    i += 2; // param + EOC
                }
            } else if (b == 0x23) { // CHIP_ERASE
                if (i + 1 < len && data[i+1] == 0x20) {
                    if (!timeout_erase) {
                        if (fail_erase) {
                            uint8_t resp[2] = {0x12, 0x11};
                            write(master_fd, resp, 2);
                        } else {
                            send_insync_ok();
                        }
                    }
                    i++;
                }
            } else if (b == 0x27) { // PROG_MULTI
                if (i + 1 < len) {
                    uint8_t plen = data[i+1];
                    if (i + 1 + plen + 1 < len && data[i + 1 + plen + 1] == 0x20) {
                        if (!timeout_prog) {
                            if (nack_prog) {
                                uint8_t resp[2] = {0x12, 0x11};
                                write(master_fd, resp, 2);
                            } else {
                                send_insync_ok();
                            }
                        }
                        i += 1 + plen + 1; // plen + data + EOC
                    }
                }
            } else if (b == 0x29) { // GET_CRC
                if (i + 1 < len && data[i+1] == 0x20) {
                    uint8_t resp[6] = {
                        (uint8_t)(expected_crc & 0xFF),
                        (uint8_t)((expected_crc >> 8) & 0xFF),
                        (uint8_t)((expected_crc >> 16) & 0xFF),
                        (uint8_t)((expected_crc >> 24) & 0xFF),
                        0x12, 0x10
                    };
                    if (fail_crc) {
                        resp[5] = 0x11;
                    }
                    write(master_fd, resp, 6);
                    i++;
                }
            } else if (b == 0x30) { // REBOOT
                if (i + 1 < len && data[i+1] == 0x20) {
                    send_insync_ok();
                    i++;
                }
            }
        }
    }

    void send_insync_ok() {
        uint8_t resp[2] = {0x12, 0x10};
        write(master_fd, resp, 2);
    }
};

class FirmwareTest : public Test {
protected:
    std::string test_dir = "/tmp/firmware_test_dir";
    std::unique_ptr<FirmwareManager> manager;
    int ws_message_count = 0;
    std::string last_ws_message;

    int suspend_calls = 0;
    int reconnect_calls = 0;
    int reboot_calls = 0;
    
    MockBootloader bootloader;
    std::string old_path;

    void SetUp() override {
        system(("rm -rf " + test_dir).c_str());
        system(("mkdir -p " + test_dir + "/bin").c_str());

        // Dummy systemctl
        std::ofstream script(test_dir + "/bin/systemctl");
        script << "#!/bin/bash\n"
               << "if [ \"$1\" == \"is-active\" ] && [ \"$2\" == \"ModemManager\" ]; then\n"
               << "  if [ -f " << test_dir << "/modem_manager_active ]; then\n"
               << "    echo \"active\"\n"
               << "  else\n"
               << "    echo \"inactive\"\n"
               << "  fi\n"
               << "fi\n";
        script.close();
        system(("chmod +x " + test_dir + "/bin/systemctl").c_str());
        
        char* current_path = getenv("PATH");
        old_path = current_path ? current_path : "";
        std::string new_path = test_dir + "/bin:" + old_path;
        setenv("PATH", new_path.c_str(), 1);

        manager = std::make_unique<FirmwareManager>(test_dir, [this](const std::string& msg) {
            ws_message_count++;
            last_ws_message = msg;
        });

        manager->set_suspend_serial_callback([this]() { suspend_calls++; });
        manager->set_reconnect_callback([this]() { reconnect_calls++; });
        manager->set_reboot_to_bootloader_callback([this]() { reboot_calls++; });
        manager->set_get_active_port_callback([]() { return "/dev/ttyS0"; });
        
        bootloader.start();
    }

    void TearDown() override {
        manager->abort();
        bootloader.stop();
        setenv("PATH", old_path.c_str(), 1);
        system(("rm -rf " + test_dir).c_str());
    }

    std::string create_dummy_apj(const std::string& filename = "dummy.apj") {
        std::string path = test_dir + "/" + filename;
        json apj = {
            {"board_id", 9},
            {"image_size", 100},
            {"image", "eJzzSM3JyQ/PL8pJ8aAZCwDWvSfZ"}  // Valid base64+zlib dummy
        };
        std::ofstream out(path);
        out << apj.dump();
        out.close();
        return path;
    }
};

// -- FirmwareManager Private Methods Tests --

TEST_F(FirmwareTest, PrivateDecodeApjEmptyImage) {
    json apj = {{"image", ""}};
    std::vector<uint8_t> out = manager->decode_apj("test", apj);
    EXPECT_TRUE(out.empty());
}

TEST_F(FirmwareTest, DecodeApjPadding) {
    // 1-byte zlib compressed payload
    json apj = {{"image", "eJzzyQAAAmwA3g=="}};
    std::vector<uint8_t> out = manager->decode_apj("test", apj);
    EXPECT_EQ(out.size(), 4); // should pad to 4
}

TEST_F(FirmwareTest, PrivateLoadApjFileNotFound) {
    std::vector<uint8_t> out = manager->load_apj_file(test_dir + "/does_not_exist.apj");
    EXPECT_TRUE(out.empty());
}

TEST_F(FirmwareTest, PrivateVerifyFirmwareFile) {
    std::string path = test_dir + "/test.apj";
    system(("touch " + path).c_str());
    EXPECT_TRUE(manager->verify_firmware_file(path));
    
    // File not found
    EXPECT_FALSE(manager->verify_firmware_file(test_dir + "/nonexistent.apj"));
    
    // Unreadable
    std::string unreadable = test_dir + "/unreadable.apj";
    system(("touch " + unreadable).c_str());
    system(("chmod 000 " + unreadable).c_str());
    EXPECT_FALSE(manager->verify_firmware_file(unreadable));
    
    // Non-apj extension warning (should still return true)
    std::string nonapj = test_dir + "/test.bin";
    system(("touch " + nonapj).c_str());
    EXPECT_TRUE(manager->verify_firmware_file(nonapj));
    EXPECT_THAT(last_ws_message, HasSubstr("File does not have a .apj extension"));
}

TEST_F(FirmwareTest, PrivateCheckModemManager) {
    // Inactive
    EXPECT_FALSE(manager->check_modem_manager());
    
    // Active
    system(("touch " + test_dir + "/modem_manager_active").c_str());
    EXPECT_TRUE(manager->check_modem_manager());
    EXPECT_THAT(last_ws_message, HasSubstr("ModemManager is running"));
}

TEST_F(FirmwareTest, PrivateSendTroubleshootingChecklist) {
    manager->send_troubleshooting_checklist("/dev/ttyDummy");
    EXPECT_THAT(last_ws_message, HasSubstr("Troubleshooting checklist"));
}

// -- FirmwareManager Public Tests --

TEST_F(FirmwareTest, InitializationAndEmptyState) {
    EXPECT_FALSE(manager->is_flashing());
    EXPECT_FALSE(manager->has_pending_install());
    EXPECT_NO_THROW(manager->abort()); // coverage for abort with no pending
}

TEST_F(FirmwareTest, WSInvalidMessage) {
    EXPECT_FALSE(manager->handle_ws_message("not a json"));
    json invalid_msg = {{"type", "unknown"}};
    EXPECT_FALSE(manager->handle_ws_message(invalid_msg.dump()));
    
    // empty type
    invalid_msg = {{"type", ""}};
    EXPECT_FALSE(manager->handle_ws_message(invalid_msg.dump()));
}

TEST_F(FirmwareTest, WSAbortMessage) {
    json abort_msg = {{"type", "abort_firmware"}};
    EXPECT_TRUE(manager->handle_ws_message(abort_msg.dump()));
}

TEST_F(FirmwareTest, InstallFirmwareNoPort) {
    create_dummy_apj("copter_stable.apj");
    json msg = {
        {"type", "install_firmware"},
        {"vehicle", "copter"},
        {"fw_type", "stable"}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    EXPECT_TRUE(manager->has_pending_install());
}

TEST_F(FirmwareTest, InstallFirmwareInvalidFile) {
    json msg = {
        {"type", "install_firmware"},
        {"vehicle", "rover"},
        {"fw_type", "stable"}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Firmware file not found"));
}

TEST_F(FirmwareTest, InstallFirmwareJsonParseError) {
    std::string path = test_dir + "/copter_stable.apj";
    std::ofstream out(path);
    out << "{ invalid json ]";
    out.close();
    
    json msg = {
        {"type", "install_firmware"},
        {"vehicle", "copter"},
        {"fw_type", "stable"}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Failed to decode"));
}

TEST_F(FirmwareTest, InstallFirmwareWithPortHotFlash) {
    std::string path = create_dummy_apj("copter_stable.apj");
    json apj;
    std::ifstream(path) >> apj;
    std::vector<uint8_t> image = manager->decode_apj("test", apj);
    bootloader.expected_crc = FirmwareUploader::compute_padded_crc(image, bootloader.flash_size);

    json msg = {
        {"type", "install_firmware"},
        {"vehicle", "copter"},
        {"fw_type", "stable"},
        {"port", bootloader.slave_name}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    
    // wait for reconnect cb
    for (int i = 0; i < 50 && reconnect_calls == 0; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    EXPECT_GT(reconnect_calls, 0);
    EXPECT_GT(reboot_calls, 0);
    EXPECT_THAT(last_ws_message, HasSubstr("FLASH COMPLETED SUCCESSFULLY"));
}

TEST_F(FirmwareTest, InstallFirmwareWithPortHotFlashPhase2Timeout) {
    // This covers wait_for_bootloader_port Phase 2 timeout
    create_dummy_apj("copter_stable.apj");
    json msg = {
        {"type", "install_firmware"},
        {"vehicle", "copter"},
        {"fw_type", "stable"},
        {"port", "/dev/nonexistent_port_for_timeout"}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    
    // wait for reconnect cb. Phase 2 timeout is 8 seconds (8000ms), plus 500ms startup delay
    for (int i = 0; i < 100 && reconnect_calls == 0; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    EXPECT_GT(reconnect_calls, 0);
}

TEST_F(FirmwareTest, CustomUploadInlineApj) {
    json custom_msg = {
        {"type", "install_firmware_custom"},
        {"apj", {
            {"board_id", 9},
            {"image_size", 100},
            {"image", "eJzzSM3JyQ/PL8pJ8aAZCwDWvSfZ"} 
        }}
    };
    EXPECT_TRUE(manager->handle_ws_message(custom_msg.dump()));
    EXPECT_TRUE(manager->has_pending_install());
    
    // Coverage for aborting pending
    manager->abort();
    EXPECT_FALSE(manager->has_pending_install());
}

TEST_F(FirmwareTest, CustomUploadInvalidInlineApj) {
    // Missing image
    json custom_msg = {
        {"type", "install_firmware_custom"},
        {"apj", {{"board_id", 9}}}
    };
    EXPECT_TRUE(manager->handle_ws_message(custom_msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Failed to decode"));

    // apj is not object
    custom_msg = {
        {"type", "install_firmware_custom"},
        {"apj", "not an object"}
    };
    EXPECT_TRUE(manager->handle_ws_message(custom_msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Invalid 'apj' field"));
    
    // image is not string
    custom_msg = {
        {"type", "install_firmware_custom"},
        {"apj", {{"image", 123}}}
    };
    EXPECT_TRUE(manager->handle_ws_message(custom_msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Failed to decode"));
    
    // invalid base64
    custom_msg = {
        {"type", "install_firmware_custom"},
        {"apj", {{"image", "!!!==="}}}
    };
    EXPECT_TRUE(manager->handle_ws_message(custom_msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Failed to decode"));
    
    // valid base64 but invalid zlib
    custom_msg = {
        {"type", "install_firmware_custom"},
        {"apj", {{"image", "AAAA"}}}
    };
    EXPECT_TRUE(manager->handle_ws_message(custom_msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Failed to decode"));
}

TEST_F(FirmwareTest, CustomUploadPathMode) {
    std::string path = create_dummy_apj("custom.apj");
    json msg = {
        {"type", "install_firmware_custom"},
        {"path", path}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    EXPECT_TRUE(manager->has_pending_install());
    
    // Trigger install_from_port
    manager->install_from_port(bootloader.slave_name);
    for (int i = 0; i < 50 && reconnect_calls == 0; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    EXPECT_FALSE(manager->has_pending_install());
}

TEST_F(FirmwareTest, CustomUploadInvalidPathMode) {
    // missing file
    json msg = {
        {"type", "install_firmware_custom"},
        {"path", test_dir + "/nonexistent.apj"}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Firmware file not found"));

    // path mode but bad json in file
    std::string bad_path = test_dir + "/bad.apj";
    std::ofstream out(bad_path); out << "bad"; out.close();
    msg = {
        {"type", "install_firmware_custom"},
        {"path", bad_path}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("Failed to decode"));

    // neither apj nor path
    msg = {
        {"type", "install_firmware_custom"}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    EXPECT_THAT(last_ws_message, HasSubstr("requires either"));
}

TEST_F(FirmwareTest, FlashBusyState) {
    bootloader.timeout_erase = true; // Hang erase
    json custom_msg = {
        {"type", "install_firmware_custom"},
        {"apj", {
            {"board_id", 9},
            {"image_size", 100},
            {"image", "eJzzSM3JyQ/PL8pJ8aAZCwDWvSfZ"} 
        }},
        {"port", bootloader.slave_name}
    };
    manager->handle_ws_message(custom_msg.dump());
    
    for(int i = 0; i < 50; i++) {
        if (manager->is_flashing()) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    EXPECT_TRUE(manager->is_flashing());
    
    // Re-install attempts while busy
    manager->handle_ws_message(custom_msg.dump());
    EXPECT_THAT(last_ws_message, HasSubstr("already in progress"));
    
    json msg = {
        {"type", "install_firmware"},
        {"vehicle", "copter"},
        {"fw_type", "stable"}
    };
    manager->handle_ws_message(msg.dump());
    EXPECT_THAT(last_ws_message, HasSubstr("already in progress"));

    manager->abort();
    for(int i = 0; i < 50 && manager->is_flashing(); i++) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

TEST_F(FirmwareTest, AbortDuringFlash) {
    bootloader.timeout_prog = true; // Hang in program phase
    std::string path = create_dummy_apj("copter_stable.apj");
    json msg = {
        {"type", "install_firmware"},
        {"vehicle", "copter"},
        {"fw_type", "stable"},
        {"port", bootloader.slave_name}
    };
    EXPECT_TRUE(manager->handle_ws_message(msg.dump()));
    
    for(int i = 0; i < 50 && !manager->is_flashing(); i++) {
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    
    manager->abort();
    
    for (int i = 0; i < 50 && manager->is_flashing(); ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    EXPECT_FALSE(manager->is_flashing());
    EXPECT_THAT(last_ws_message, HasSubstr("cancelled by user"));
}

TEST_F(FirmwareTest, VerifyPortAccessNoPermissions) {
    // Create a file that EXISTS but has no read/write permission
    std::string noperm_port = test_dir + "/noperm_port";
    system(("touch " + noperm_port).c_str());
    system(("chmod 000 " + noperm_port).c_str());

    // Call do_flash directly (private but #define private public)
    // This bypasses wait_for_bootloader_port and directly tests verify_port_access
    std::vector<uint8_t> dummy = {0x01, 0x02, 0x03};
    manager->do_flash(noperm_port, dummy, "test");

    system(("chmod 644 " + noperm_port).c_str()); // cleanup
    EXPECT_THAT(last_ws_message, HasSubstr("No read/write access"));
}

TEST_F(FirmwareTest, DoFlashSuccessPath) {
    // Call do_flash directly with a valid PTY port and correct CRC
    // This covers the flash complete / reconnect_cb success path (lines 858-862)
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    bootloader.expected_crc = FirmwareUploader::compute_padded_crc(dummy_image, bootloader.flash_size);

    manager->do_flash(bootloader.slave_name, dummy_image, "direct_test");

    EXPECT_THAT(last_ws_message, HasSubstr("FLASH COMPLETED SUCCESSFULLY"));
    EXPECT_GT(reconnect_calls, 0);
}

// -- FirmwareUploader Tests --

TEST_F(FirmwareTest, UploaderFlashEmptyImage) {
    FirmwareUploader uploader;
    std::vector<uint8_t> empty;
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, empty));
}

TEST_F(FirmwareTest, UploaderFlashInvalidPort) {
    FirmwareUploader uploader;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    bool result = uploader.flash("/invalid/port/does/not/exist", 115200, dummy_image, 9);
    EXPECT_FALSE(result);
}

TEST_F(FirmwareTest, UploaderOpenPortTwice) {
    FirmwareUploader uploader;
    // open_port is private but we have #define private public
    EXPECT_TRUE(uploader.open_port(bootloader.slave_name, 115200));
    // Calling it again should trigger the is_open() check
    EXPECT_TRUE(uploader.open_port(bootloader.slave_name, 115200));
}

TEST_F(FirmwareTest, UploaderEnterBootloaderRetries) {
    FirmwareUploader uploader;
    bootloader.sync_retries_needed = 8; // fail initial GET_SYNC and post-0x7F syncs, triggering DTR
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    bootloader.expected_crc = FirmwareUploader::compute_padded_crc(dummy_image, bootloader.flash_size);
    EXPECT_TRUE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 9));
}

TEST_F(FirmwareTest, UploaderGetDeviceTimeout) {
    FirmwareUploader uploader;
    bootloader.timeout_get_device = true;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 9));
}

TEST_F(FirmwareTest, UploaderWriteBytesException) {
    FirmwareUploader uploader;
    EXPECT_TRUE(uploader.open_port(bootloader.slave_name, 115200));
    
    // Close the underlying FD behind ASIO's back to force a write error
    int fd = uploader.port_.native_handle();
    ::close(fd);

    uint8_t dummy = 0x00;
    EXPECT_FALSE(uploader.write_bytes(&dummy, 1));
}


TEST_F(FirmwareTest, UploaderFlashBoardIdMismatch) {
    FirmwareUploader uploader;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    // Expected ID 10, but mock returns 9
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 10));
}

TEST_F(FirmwareTest, UploaderFlashImageTooLarge) {
    FirmwareUploader uploader;
    std::vector<uint8_t> large_image(200, 0x01); // 200 > mock's 100 flash_size
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, large_image, 9));
}

TEST_F(FirmwareTest, UploaderGetDeviceInfoInvalid) {
    FirmwareUploader uploader;
    bootloader.invalid_device_info = true;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 9));
}

TEST_F(FirmwareTest, UploaderGetDeviceInfoUnexpectedStatus) {
    FirmwareUploader uploader;
    bootloader.unexpected_status_device = true;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 9));
}

TEST_F(FirmwareTest, UploaderEraseFail) {
    FirmwareUploader uploader;
    bootloader.fail_erase = true;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 9));
}

TEST_F(FirmwareTest, UploaderEraseTimeout) {
    FirmwareUploader uploader;
    bootloader.timeout_erase = true;
    
    std::atomic<bool> done{false};
    std::thread t([&]() {
        std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
        uploader.flash(bootloader.slave_name, 115200, dummy_image, 9);
        done = true;
    });

    // Let it start erasing, then abort to simulate timeout/abort during erase
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    uploader.abort();
    t.join();
    EXPECT_TRUE(done);
}

TEST_F(FirmwareTest, UploaderProgramNack) {
    FirmwareUploader uploader;
    bootloader.nack_prog = true;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 9));
}

TEST_F(FirmwareTest, UploaderProgramTimeout) {
    FirmwareUploader uploader;
    bootloader.timeout_prog = true;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 9));
}

TEST_F(FirmwareTest, UploaderVerifyCrcFail) {
    FirmwareUploader uploader;
    bootloader.fail_crc = true;
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    EXPECT_FALSE(uploader.flash(bootloader.slave_name, 115200, dummy_image, 9));
}

TEST_F(FirmwareTest, UploaderDrainAndCallbacks) {
    FirmwareUploader uploader;
    
    bool log_called = false;
    bool erase_cb_called = false;
    bool write_cb_called = false;
    
    uploader.set_log_callback([&](const std::string&) { log_called = true; });
    uploader.set_erase_progress([&](float) { erase_cb_called = true; });
    uploader.set_write_progress([&](float) { write_cb_called = true; });
    
    std::vector<uint8_t> dummy_image = {0x01, 0x02, 0x03};
    uploader.flash(bootloader.slave_name, 115200, dummy_image, 9);
    
    EXPECT_TRUE(log_called);
    EXPECT_TRUE(erase_cb_called);
    EXPECT_TRUE(write_cb_called);
}

TEST_F(FirmwareTest, PrivateDecodeApj) {
    // Hit zlib fail path in decode_apj directly
    json apj = {
        {"image", "AAAA"} // invalid zlib payload
    };
    std::vector<uint8_t> out = manager->decode_apj("test", apj);
    EXPECT_TRUE(out.empty());
}
