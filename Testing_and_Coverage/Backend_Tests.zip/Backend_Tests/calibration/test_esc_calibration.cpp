#include <gtest/gtest.h>
#include "calibration/esc_calibration.h"
#include <thread>
#include <chrono>

// UT-CAL-ESC-001: Initialization
TEST(EscCalibrationTest, Initialization) {
    EscCalibration esc;
    esc.setVehicleInfo(1, 1);
}

// UT-CAL-ESC-002: Missing Transport Callback
TEST(EscCalibrationTest, MissingTransportCallback) {
    EscCalibration esc;
    esc.setVehicleInfo(1, 1);
    
    bool json_sent = false;
    esc.setSendCallback([&](const std::string& json) {
        json_sent = true;
    });
    
    esc.startEscCalibration();
    EXPECT_TRUE(json_sent);
}

// Helper function to run startEscCalibration in a background thread and provide responses
void runEscTest(int result_code, int num_responses, bool wait_timeout, bool cancel) {
    EscCalibration esc;
    esc.setVehicleInfo(1, 1);
    
    esc.setTransportCallback([&](const mavlink_message_t& msg) {
        if (msg.msgid == MAVLINK_MSG_ID_PARAM_SET) {
            // Respond to PARAM_SET? No, it waits for COMMAND_ACK for MAV_CMD_PREFLIGHT_CALIBRATION
        }
    });
    
    std::thread t([&]() {
        esc.startEscCalibration();
    });
    
    // Give thread time to send preflight command
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    
    if (cancel) {
        esc.cancelEscCalibration();
    } else if (!wait_timeout) {
        for (int i = 0; i < num_responses; ++i) {
            mavlink_message_t msg;
            mavlink_command_ack_t ack = {};
            ack.command = MAV_CMD_PREFLIGHT_CALIBRATION;
            ack.result = result_code;
            mavlink_msg_command_ack_encode(1, 1, &msg, &ack);
            esc.processMessage(msg);
            
            if (i < num_responses - 1) {
                // Wait before sending next response (e.g. for retry loop)
                std::this_thread::sleep_for(std::chrono::milliseconds(2100));
            }
        }
    }
    
    if (wait_timeout) {
        // Wait for the timeout to occur natively (3 seconds)
        // No wait needed here, join will block until timeout occurs
    }
    
    if (t.joinable()) {
        t.join();
    }
}

// UT-CAL-ESC-003: Accepted
TEST(EscCalibrationTest, Accepted) {
    runEscTest(MAV_RESULT_ACCEPTED, 1, false, false);
}

// UT-CAL-ESC-004: Unsupported (Soft Accept)
TEST(EscCalibrationTest, Unsupported) {
    runEscTest(MAV_RESULT_UNSUPPORTED, 1, false, false);
}

// UT-CAL-ESC-005: Denied (Hard Failure)
TEST(EscCalibrationTest, Denied) {
    runEscTest(MAV_RESULT_DENIED, 1, false, false);
}

// UT-CAL-ESC-006: Timeout
TEST(EscCalibrationTest, Timeout) {
    // Too slow for quick unit tests without mocking clock, but we can call cancel early to simulate
    runEscTest(0, 0, false, true);
}

// UT-CAL-ESC-007: Temporarily Rejected Exhaustion
TEST(EscCalibrationTest, TemporarilyRejectedExhaustion) {
    EscCalibration esc;
    esc.setVehicleInfo(1, 1);
    
    esc.setTransportCallback([&](const mavlink_message_t& msg) {
        // Do nothing
    });
    
    // Run start in a thread
    std::thread t([&]() {
        esc.startEscCalibration();
    });
    
    // Send 3 temporary rejections to trigger exhaustion
    for (int i = 0; i < 3; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        mavlink_message_t msg;
        mavlink_command_ack_t ack = {};
        ack.command = MAV_CMD_PREFLIGHT_CALIBRATION;
        ack.result = MAV_RESULT_TEMPORARILY_REJECTED;
        mavlink_msg_command_ack_encode(1, 1, &msg, &ack);
        esc.processMessage(msg);
    }
    
    if (t.joinable()) {
        t.join();
    }
}

// UT-CAL-ESC-008: Other Messages
TEST(EscCalibrationTest, OtherMessages) {
    EscCalibration esc;
    esc.setVehicleInfo(1, 1);
    
    // Send unrelated message
    mavlink_message_t msg;
    mavlink_heartbeat_t hb = {};
    mavlink_msg_heartbeat_encode(1, 1, &msg, &hb);
    esc.processMessage(msg);
    
    // Send wrong ack
    mavlink_command_ack_t ack = {};
    ack.command = MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN;
    mavlink_msg_command_ack_encode(1, 1, &msg, &ack);
    esc.processMessage(msg);
}

// UT-CAL-ESC-009: Duplicate Start
TEST(EscCalibrationTest, DuplicateStart) {
    EscCalibration esc;
    esc.setVehicleInfo(1, 1);
    esc.setTransportCallback([&](const mavlink_message_t& msg) {});
    
    std::thread t([&]() {
        esc.startEscCalibration();
    });
    
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    
    // This duplicate start should return immediately
    esc.startEscCalibration();
    
    esc.cancelEscCalibration();
    if (t.joinable()) {
        t.join();
    }
}

TEST(EscCalibrationTest, CancelAndCallbacks) {
    EscCalibration esc;
    esc.setVehicleInfo(1, 1);
    bool json_sent = false;
    esc.setSendCallback([&](const std::string& json) { json_sent = true; });
    esc.startEscCalibration();
    esc.cancelEscCalibration();
}
