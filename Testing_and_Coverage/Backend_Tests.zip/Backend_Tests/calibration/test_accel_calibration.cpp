#include <gtest/gtest.h>
#include "calibration/accel_calibration.h"

TEST(AccelCalibrationTest, Initialization) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::IDLE);
}

TEST(AccelCalibrationTest, ArmedRejection) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    
    // Send heartbeat indicating armed
    mavlink_message_t msg;
    mavlink_heartbeat_t hb = {};
    hb.base_mode = MAV_MODE_FLAG_SAFETY_ARMED;
    mavlink_msg_heartbeat_encode(1, 1, &msg, &hb);
    accel.processMessage(msg);
    
    bool json_sent = false;
    accel.setSendCallback([&](const std::string& json) {
        json_sent = true;
    });
    
    accel.startAccelCalibration();
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::IDLE);
    EXPECT_TRUE(json_sent);
    
    json_sent = false;
    accel.startLevelCalibration();
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::IDLE);
    EXPECT_TRUE(json_sent);
}

TEST(AccelCalibrationTest, DuplicateStart) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    accel.startAccelCalibration();
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::IN_PROGRESS);
}

TEST(AccelCalibrationTest, ProcessAttitude) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    
    bool json_sent = false;
    accel.setSendCallback([&](const std::string& json) {
        json_sent = true;
    });
    
    accel.startAccelCalibration();
    
    mavlink_message_t msg;
    mavlink_attitude_t att = {};
    att.roll = 0.5f;
    att.pitch = 0.5f;
    att.yaw = 0.5f;
    mavlink_msg_attitude_encode(1, 1, &msg, &att);
    accel.processMessage(msg);
    
    EXPECT_TRUE(json_sent);
}

TEST(AccelCalibrationTest, ProcessPreflightAckRejected) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    
    mavlink_message_t msg;
    mavlink_command_ack_t ack = {};
    ack.command = MAV_CMD_PREFLIGHT_CALIBRATION;
    ack.result = MAV_RESULT_DENIED;
    mavlink_msg_command_ack_encode(1, 1, &msg, &ack);
    
    accel.processMessage(msg);
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::FAILED);
}

TEST(AccelCalibrationTest, ProcessStatusText) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    
    mavlink_message_t msg;
    mavlink_statustext_t st = {};
    
    // Test position
    strcpy(st.text, "Place vehicle level and press any key.");
    mavlink_msg_statustext_encode(1, 1, &msg, &st);
    accel.processMessage(msg);
    EXPECT_EQ(accel.pendingPosition, 1);
    
    // Test failure
    accel.pendingPosition = 0; // Fix: Reset pending position for the failure test
    strcpy(st.text, "Calibration FAILED");
    mavlink_msg_statustext_encode(1, 1, &msg, &st);
    accel.processMessage(msg);
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::FAILED);
}

TEST(AccelCalibrationTest, SuccessfulCalibrationFlow) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    
    mavlink_message_t msg;
    
    // ACK
    mavlink_command_ack_t ack = {};
    ack.command = MAV_CMD_PREFLIGHT_CALIBRATION;
    ack.result = MAV_RESULT_ACCEPTED;
    mavlink_msg_command_ack_encode(1, 1, &msg, &ack);
    accel.processMessage(msg);
    
    // Position 1
    mavlink_command_long_t pos_cmd = {};
    pos_cmd.command = MAV_CMD_ACCELCAL_VEHICLE_POS;
    pos_cmd.param1 = 1;
    mavlink_msg_command_long_encode(1, 1, &msg, &pos_cmd);
    accel.processMessage(msg);
    
    // Confirm 1
    accel.confirmAccelPosition();
    
    // Position 2
    pos_cmd.param1 = 2;
    mavlink_msg_command_long_encode(1, 1, &msg, &pos_cmd);
    accel.processMessage(msg);
    
    // Wait for the step timeout thread to process
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    
    // Pre-confirm 3
    accel.confirmAccelPosition();
    
    // Position 3 (should auto-confirm)
    pos_cmd.param1 = 3;
    mavlink_msg_command_long_encode(1, 1, &msg, &pos_cmd);
    accel.processMessage(msg);
    
    // Success
    pos_cmd.param1 = 16384;
    mavlink_msg_command_long_encode(1, 1, &msg, &pos_cmd);
    accel.processMessage(msg);
    
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::DONE);
}

TEST(AccelCalibrationTest, ValidateAttitude) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    
    mavlink_message_t msg;
    mavlink_attitude_t att = {};
    att.roll = 1.0f; // Wrong
    att.pitch = 0.0f;
    att.yaw = 0.0f;
    mavlink_msg_attitude_encode(1, 1, &msg, &att);
    accel.processMessage(msg);
    
    mavlink_command_long_t pos_cmd = {};
    pos_cmd.command = MAV_CMD_ACCELCAL_VEHICLE_POS;
    pos_cmd.param1 = 1; // LEVEL
    mavlink_msg_command_long_encode(1, 1, &msg, &pos_cmd);
    accel.processMessage(msg);
    
    // Should warn but still confirm
    accel.confirmAccelPosition();
}

TEST(AccelCalibrationTest, StatusTextPositions) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    
    mavlink_message_t msg;
    mavlink_statustext_t st = {};
    
    const char* positions[] = {
        "level", "LEFT", "RIGHT", "NOSE DOWN", "NOSE UP", "UPSIDE DOWN"
    };
    
    for (int i = 0; i < 6; ++i) {
        strcpy(st.text, positions[i]);
        mavlink_msg_statustext_encode(1, 1, &msg, &st);
        accel.processMessage(msg);
        EXPECT_EQ(accel.pendingPosition, i + 1);
        accel.confirmAccelPosition();
    }
}

TEST(AccelCalibrationTest, StatusTextSuccessFailed) {
    AccelCalibration accel;
    
    // Success
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    mavlink_message_t msg;
    mavlink_statustext_t st = {};
    strcpy(st.text, "Calibration successful");
    mavlink_msg_statustext_encode(1, 1, &msg, &st);
    accel.processMessage(msg);
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::DONE);
    
    // Failed
    AccelCalibration accel2;
    accel2.setVehicleInfo(1, 1);
    accel2.startAccelCalibration();
    strcpy(st.text, "calibration failed");
    mavlink_msg_statustext_encode(1, 1, &msg, &st);
    accel2.processMessage(msg);
    EXPECT_EQ(accel2.accelState, AccelCalibration::AccelCalibState::FAILED);
}

TEST(AccelCalibrationTest, HandleAccelVehiclePosFailure) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    
    mavlink_message_t msg;
    mavlink_command_long_t pos_cmd = {};
    pos_cmd.command = MAV_CMD_ACCELCAL_VEHICLE_POS;
    
    // Test Failed
    pos_cmd.param1 = 16385; // ACCELCAL_POS_FAILED
    mavlink_msg_command_long_encode(1, 1, &msg, &pos_cmd);
    accel.processMessage(msg);
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::FAILED);
}

TEST(AccelCalibrationTest, CancelCalibration) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    bool json_sent = false;
    accel.setSendCallback([&](const std::string& json) { json_sent = true; });
    accel.startAccelCalibration();
    // Accel doesn't have cancel
}

TEST(AccelCalibrationTest, HandleVehiclePosAckRejected) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    bool json_sent = false;
    accel.setSendCallback([&](const std::string& json) { json_sent = true; });
    accel.startAccelCalibration();

    mavlink_message_t msg;
    mavlink_command_ack_t ack = {};
    ack.command = MAV_CMD_ACCELCAL_VEHICLE_POS;
    ack.result = MAV_RESULT_DENIED;
    mavlink_msg_command_ack_encode(1, 1, &msg, &ack);
    accel.processMessage(msg);
    EXPECT_EQ(accel.accelState, AccelCalibration::AccelCalibState::FAILED);
}

TEST(AccelCalibrationTest, HeartbeatLandedState) {
    AccelCalibration accel;
    accel.setVehicleInfo(1, 1);
    accel.startAccelCalibration();
    
    mavlink_message_t msg;
    mavlink_heartbeat_t hb = {};
    hb.base_mode = MAV_MODE_FLAG_SAFETY_ARMED;
    mavlink_msg_heartbeat_encode(1, 1, &msg, &hb);
    accel.processMessage(msg); // Should trigger failure if armed while in progress
}

